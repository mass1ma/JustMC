#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// CUBED_PACK
bool roughlyEquals(float a, float b) {
    return abs(a - b) < 0.01;
}
bool colorEQ(vec3 ColorA, vec3 ColorB) {
    return length(ColorA - ColorB) < 0.002;
}
vec3 color_to_vec(float r, float g, float b) {
    return vec3(r / 255.0, g / 255.0, b / 255.0);
}
vec4 fullScreenQuad(vec4 Pos) {
    const vec2[4] corners = vec2[4](vec2(-1, 1), vec2(-1, -1), vec2(1, -1), vec2(1, 1));
    vec2 corner = corners[gl_VertexID % 4];
    Pos.xy = corner;
    Pos.z -= 0.1;
    return Pos;
}

void main() {
    vec4 Pos = vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    // CUBED_PACK
    // solid color
    if (
        roughlyEquals(Position.z, 2400.12) || // title color
        roughlyEquals(Position.z, 2400.06) || // subtitile color
        roughlyEquals(Position.z, 2200.03) || // actionbar color
        roughlyEquals(Position.z, 1000.03)    // bossbar color
    ) {
        if (colorEQ(Color.xyz, color_to_vec(70.0, 80.0, 40.0))) { // crosshair
            vertexColor.rgb = vec3(1.0) * texelFetch(Sampler2, UV2 / 16, 0).rgb;
        }
        if (colorEQ(Color.xyz, color_to_vec(70.0, 80.0, 42.0))) { // death bg
            vertexColor = vec4(1.0, 0.0, 0.0, clamp(vertexColor.a, 0.0, 0.6)) * texelFetch(Sampler2, UV2 / 16, 0);
            gl_Position = fullScreenQuad(ProjMat * ModelViewMat * Pos);
            return;
        }
        if (colorEQ(Color.xyz, color_to_vec(122.0, 80.0, 60.0))) { // white quad
            vertexColor.rgb = vec3(1.0) * texelFetch(Sampler2, UV2 / 16, 0).rgb;
            gl_Position = fullScreenQuad(ProjMat * ModelViewMat * Pos);
            return;
        }
        if (colorEQ(Color.xyz, color_to_vec(120.0, 80.0, 60.0))) { // black quad
            vertexColor.rgb = vec3(0.0) * texelFetch(Sampler2, UV2 / 16, 0).rgb;
            Pos = ProjMat * ModelViewMat * Pos;
            if (roughlyEquals(Position.z, 1000.03)) {
                Pos.z += 0.12;
            }
            gl_Position = fullScreenQuad(Pos);
            return;
        }
    }
    if (
        roughlyEquals(Position.z, 600.0) && // xp number
        colorEQ(Color.xyz, color_to_vec(128.0, 255.0, 32.0))
    ) {
        vertexColor = vec4(color_to_vec(255.0, 154.0, 0.0), 1);
    }
    // remove shadow
    if (
        roughlyEquals(Position.z, 2400) || // titile and subtitle shadow
        roughlyEquals(Position.z, 2200) || // actionbar shadow
        roughlyEquals(Position.z, 1000)    // bossbar shadow
    ) {
        if (
            colorEQ(Color.xyz, color_to_vec(17.0, 20.0, 10.0)) ||
            colorEQ(Color.xyz, color_to_vec(30.0, 20.0, 15.0))
        ) { // crosshair + death bg + quads
            vertexColor = vec4(0.0);
        }
    }

    gl_Position = ProjMat * ModelViewMat * Pos;
}
