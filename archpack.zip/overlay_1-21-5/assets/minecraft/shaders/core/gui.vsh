#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;

// CUBED_PACK
bool colorAlphaEQ(vec4 ColorA, vec4 ColorB) {
    return length(ColorA - ColorB) < 0.002;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;

    // CUBED_PACK
    // disable cooldown and simillar stuff
    if (colorAlphaEQ(Color, vec4(1.0, 1.0, 1.0, 0.5))) {
        vertexColor = vec4(0.0);
    }
}
