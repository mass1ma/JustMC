#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// CUBED_PACK
bool colorEQ(vec3 ColorA, vec3 ColorB) {
    return length(ColorA - ColorB) < 0.002;
}
vec3 color_to_vec(float r, float g, float b) {
    return vec3(r / 255.0, g / 255.0, b / 255.0);
}

void main() {
    vec4 Pos = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    // CUBED_PACK
    if (colorEQ(Color.xyz, color_to_vec(200.0, 190.0, 132.0))) { // sign text
        vertexColor.rgb = vec3(0.0) * texelFetch(Sampler2, UV2 / 16, 0).rgb;
        Pos.z -= 0.001;
    }

    gl_Position = Pos;
}
