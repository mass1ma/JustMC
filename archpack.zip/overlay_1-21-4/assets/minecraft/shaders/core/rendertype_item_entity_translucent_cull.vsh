#version 150

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;

out float vertexDistance;
out vec4 vertexColor;

// CUBED_PACK
uniform sampler2D Sampler0;
flat out int isEffect;
// OBJMC
uniform float FogStart;
uniform float GameTime;
out vec3 Pos;
out vec2 texCoord;
out vec2 texCoord2;
out vec4 lightColor;
out vec4 overlayColor;
out float transition;
flat out int isCustom;
flat out int isGUI;
flat out int isHand;
flat out int noshadow;
#moj_import <objmc_tools.glsl>

// CUBED_PACK
bool colorEQ(vec3 ColorA, vec3 ColorB) {
    return length(ColorA - ColorB) < 0.002;
}
bool colorAlphaEQ(vec4 ColorA, vec4 ColorB) {
    return length(ColorA - ColorB) < 0.002;
}
vec4 getVertexColor(sampler2D Sampler, int vertexID, vec2 coords) {
    ivec2 texSize = textureSize(Sampler, 0);
    vec2 offset = vec2(0.0);
    float pixelX = (1.0 / texSize.x) * 0.498;
    float pixelY = (1.0 / texSize.y) * 0.498;
    vertexID = vertexID % 4;
    switch(vertexID) {
        case 1: offset = vec2(-pixelX, pixelY); break;
        case 2: offset = vec2(pixelX, pixelY); break;
        case 3: offset = vec2(pixelX, -pixelY); break;
        case 0: offset = vec2(-pixelX, -pixelY); break;
        default: offset = vec2(0.0); break;
    }
    return texture(Sampler, coords - offset);
}

void main() {
    Pos = Position;
    texCoord = UV0;
    texCoord2 = UV2;

    // OBJMC
    lightColor = minecraft_sample_lightmap(Sampler2, UV2);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    overlayColor = vec4(1);

    // CUBED_PACK
    isEffect = 0;
    vec4 cbTexColor = getVertexColor(Sampler0, gl_VertexID, texCoord);
    if (
        colorEQ(cbTexColor.rgb, vec3(160.0/255.0)) ||
        colorAlphaEQ(cbTexColor, vec4(0.0, 0.0, 0.0, 180.0/255.0))
    ) {
        vertexColor = vec4(1.0);
        lightColor = vec4(1.0);
    } else if (
        colorAlphaEQ(cbTexColor, vec4(0.0, 1.0, 1.0, 16.0/255.0))
    ) {
        vertexColor = vec4(1.0);
        lightColor = vec4(1.0);
        isEffect = 1;
    }
    // OBJMC
    #define ENTITY
    #moj_import <objmc_main.glsl>

    gl_Position = ProjMat * ModelViewMat * vec4(Pos, 1.0);
    vertexDistance = fog_distance(Pos, FogShape);
}
