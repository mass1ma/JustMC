#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;

bool colorEQ(vec3 ColorA, vec3 ColorB) {
    return length(ColorA - ColorB) < 0.002;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;

    // disable cooldown (old)
    if (
        Position.z == 0.0 &&
        colorEQ(Color.rgb, vec3(1.0)) &&
        Color.a > 0.498 && Color.a < 0.5
    ) {
        vertexColor = vec4(0.0);
    }
}
