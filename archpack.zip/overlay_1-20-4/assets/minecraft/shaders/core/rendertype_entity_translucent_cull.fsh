#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

// CUBED_PACK
flat in int isEffect;
// OBJMC
#moj_import <light.glsl>
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;
in vec3 Pos;
in vec2 texCoord;
in vec2 texCoord2;
in vec4 lightColor;
in vec4 overlayColor;
in float transition;
flat in int isCustom;
flat in int isGUI;
flat in int isHand;
flat in int noshadow;

void main() {
    vec4 cbBaseColor = texture(Sampler0, texCoord);
    vec4 color = mix(cbBaseColor, texture(Sampler0, texCoord2), transition);

    // OBJMC
    #define ENTITY
    #moj_import<objmc_light.glsl>

    if (color.a < 0.1) {
        discard;
    }

    // CUBED_PACK
    int alpha = int(cbBaseColor.a * 255.0);
    if (isEffect == 0) {
        if (alpha == 245 || alpha == 243 || alpha == 241) {
            if (alpha == 245) cbBaseColor.a = 200.0/255.0;
            if (alpha == 243) cbBaseColor.a = 127.0/255.0;
            if (alpha == 241) cbBaseColor.a = 50.0/255.0;
            fragColor = cbBaseColor;
            return;
        }
        if (alpha == 250) {
            fragColor = cbBaseColor;
            fragColor.a = 1.0;
            return;
        }
    } else {
        fragColor = cbBaseColor;
        return;
    }

    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
