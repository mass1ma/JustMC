#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform mat4 TextureMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec2 texCoord0;

// CUBED_PACK
uniform float GameTime;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = fog_distance(ModelViewMat, Position, FogShape);
    lightMapColor = texelFetch(Sampler2, UV2 / 16, 0);
    //vertexColor = Color * lightMapColor;

    // CUBED_PACK
    float time = GameTime * (18000.0 * 3.14159 / 180.0);
    vertexColor = Color * mix(vec4(255.0/255.0, 154.0/255.0, 0.0/255.0, 1), vec4(255.0/255.0, 210.0/255.0, 0.0/255.0, 1), sin(time));

    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
}
